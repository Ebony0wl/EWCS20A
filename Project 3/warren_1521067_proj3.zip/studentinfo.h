#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

//Replace "Your Name" and "Your ID#";
namespace StudentInfo {
	std::string name() {
        return "Ebony Warren"; }
    
	std::string id() {
        return "1521067"; }
    
};

#endif
