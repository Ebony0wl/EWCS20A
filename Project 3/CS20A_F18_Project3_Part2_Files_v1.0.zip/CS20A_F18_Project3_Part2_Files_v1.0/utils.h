// Some utility functions
#ifndef UTILS_H
#define UTILS_H
int randInt(int min, int max);
void delay(int ms);
void clearScreen();
#endif//UTILS_H