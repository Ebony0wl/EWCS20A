//
//  utils.h
//  Project 1
//
//  Created by Ebony Warren on 9/21/18.
//  Copyright © 2018 CS20A. All rights reserved.
//

#ifndef utils_h
#define utils_h

void clearScreen();
void delay(int ms);

#endif /* utils_h */
